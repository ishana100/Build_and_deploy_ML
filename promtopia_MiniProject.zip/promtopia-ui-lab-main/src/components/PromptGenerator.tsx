import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ThumbsUp, ThumbsDown } from "lucide-react";
import topiMascot from "@/assets/topi-mascot.png";

const AI_MODELS = ["ChatGPT", "Gemini", "Claude", "Mistral"];

const SAMPLE_PROMPTS = {
  "ChatGPT": "Please help me compose a friendly, casual email to a friend. The tone should be warm and conversational, checking in on how they've been doing lately.",
  "Gemini": "Generate a friendly email message to catch up with a friend. Use a casual, warm tone and ask about their well-being.",
  "Claude": "I'd like to write a friendly email to a friend. Please help me craft a warm, conversational message that expresses care and interest in how they're doing.",
  "Mistral": "Create a casual, friendly email for catching up with a friend. The message should be warm and show genuine interest in their life."
};

const PromptGenerator = () => {
  const [task, setTask] = useState("");
  const [model, setModel] = useState("");
  const [generatedPrompt, setGeneratedPrompt] = useState("");
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null);

  const handleGenerate = () => {
    if (task && model) {
      setGeneratedPrompt(SAMPLE_PROMPTS[model as keyof typeof SAMPLE_PROMPTS] || "Your optimized prompt will appear here!");
      setFeedback(null);
    }
  };

  return (
    <div className="bg-card border-4 border-foreground rounded-[2rem] p-8 md:p-12 shadow-lg">
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="space-y-3">
          <label className="text-xl font-semibold text-foreground block">
            Enter a task or topic:
          </label>
          <Input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="Write an email to friend"
            className="text-lg border-4 border-foreground rounded-[1.5rem] h-14 px-6"
          />
        </div>

        <div className="space-y-3">
          <label className="text-xl font-semibold text-foreground block">
            Select a model:
          </label>
          <Select value={model} onValueChange={setModel}>
            <SelectTrigger className="text-lg border-4 border-foreground rounded-[1.5rem] h-14 px-6 bg-card">
              <SelectValue placeholder="ChatGPT" />
            </SelectTrigger>
            <SelectContent className="border-4 border-foreground rounded-[1.5rem] bg-card">
              {AI_MODELS.map((m) => (
                <SelectItem key={m} value={m} className="text-lg">
                  {m}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-center mb-8">
        <Button
          onClick={handleGenerate}
          className="bg-primary hover:bg-primary/90 text-foreground font-semibold text-lg px-12 py-6 rounded-[1.5rem] border-4 border-foreground shadow-lg hover:scale-105 transition-all duration-200 hover:shadow-xl"
        >
          Generate Prompt
        </Button>
      </div>

      {generatedPrompt && (
        <div className="animate-fade-in">
          <h3 className="text-xl font-semibold text-foreground mb-4">
            Generated Prompt:
          </h3>
          <div className="flex gap-6 items-start">
            <div className="flex-shrink-0">
              <div className="w-32 h-32 bg-primary border-4 border-foreground rounded-[1.5rem] flex items-center justify-center overflow-hidden animate-float">
                <img src={topiMascot} alt="Topi mascot" className="w-full h-full object-cover" />
              </div>
            </div>
            <div className="flex-1 bg-secondary border-4 border-foreground rounded-[1.5rem] p-6 relative">
              <p className="text-lg text-foreground leading-relaxed">
                {generatedPrompt}
              </p>
              <div className="flex gap-2 mt-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFeedback("up")}
                  className={`hover:bg-primary/20 ${
                    feedback === "up" ? "bg-primary/30" : ""
                  }`}
                >
                  <ThumbsUp className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFeedback("down")}
                  className={`hover:bg-primary/20 ${
                    feedback === "down" ? "bg-primary/30" : ""
                  }`}
                >
                  <ThumbsDown className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptGenerator;
