import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="bg-primary border-b-4 border-foreground">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-foreground rounded-full" />
            <div className="w-3 h-3 bg-foreground rounded-full" />
            <h1 className="text-2xl md:text-3xl font-bold text-foreground ml-6">
              PROMPTOPIA
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <Link 
              to="/" 
              className="text-lg font-medium text-foreground hover:scale-105 transition-transform"
            >
              Home
            </Link>
            <Link 
              to="#features" 
              className="text-lg font-medium text-foreground hover:scale-105 transition-transform"
            >
              Features
            </Link>
            <Link 
              to="#about" 
              className="text-lg font-medium text-foreground hover:scale-105 transition-transform"
            >
              About
            </Link>
            <Link 
              to="#contact" 
              className="text-lg font-medium text-foreground hover:scale-105 transition-transform"
            >
              Contact
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
