import Header from "@/components/Header";
import PromptGenerator from "@/components/PromptGenerator";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-6 py-12">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Generate Perfect AI Prompts
            </h2>
            <p className="text-xl text-muted-foreground">
              Optimize your prompts for ChatGPT, Gemini, Claude, and Mistral
            </p>
          </div>
          <PromptGenerator />
        </div>
      </main>
    </div>
  );
};

export default Index;
